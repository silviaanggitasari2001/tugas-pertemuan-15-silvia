<?php 
header('location:pasien/daftar.php');




 ?>